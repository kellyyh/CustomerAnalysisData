# Customer-Analysis-Tableau
This repository contains the data source (sales_06_FY2020-21.csv.zip) and the tableau workbook (CustomerAnalysis.twb)
used in my YouTube video: https://www.youtube.com/watch?v=_qReGTOrKTk
